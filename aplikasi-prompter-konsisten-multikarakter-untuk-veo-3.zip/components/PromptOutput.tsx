import React, { useState, useCallback } from 'react';

interface PromptOutputProps {
  indonesianPrompt: string;
  englishPrompt: string;
  onIndonesianPromptChange: (newPrompt: string) => void;
}

const CopyIcon: React.FC<{className?: string}> = ({className}) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className || "w-5 h-5"}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 17.25v3.375c0 .621-.504 1.125-1.125 1.125h-9.75a1.125 1.125 0 01-1.125-1.125V7.875c0-.621.504-1.125 1.125-1.125H6.75a9.06 9.06 0 011.5.124m7.5 10.376h3.375c.621 0 1.125-.504 1.125-1.125V11.25c0-4.46-3.243-8.161-7.5-8.876a9.06 9.06 0 00-1.5-.124H9.375c-.621 0-1.125.504-1.125 1.125v3.5m7.5 10.375H9.375a1.125 1.125 0 01-1.125-1.125v-9.25m9.75 0h-3.375c-.621 0-1.125.504-1.125 1.125v6.625c0 .621.504 1.125 1.125 1.125h3.375m0-9.75a1.125 1.125 0 00-1.125-1.125H18c-1.125 0-2.096.006-2.903.018M15 3.018a1.5 1.5 0 00-1.018.44M15 3.018a1.5 1.5 0 011.018.44m-1.018-.44V6.375m0-3.357a1.5 1.5 0 00-1.018-.44m1.018.44H15m0-3.357a1.5 1.5 0 011.018-.44M15 3.018a1.5 1.5 0 00-1.018.44m1.018.44L10.5 8.25m0 0a1.125 1.125 0 01-1.591 0L3.375 2.712V6.375m0 0A1.125 1.125 0 014.5 7.5h3.375M10.5 8.25L6.75 4.5M3.375 6.375V11.25A1.125 1.125 0 004.5 12.375h3.375M10.5 8.25L9 9.75M15 12.375V15m0 0A1.125 1.125 0 0113.875 16.125H12.375m1.5-1.125H15M9.75 15h-3M15 12.375V9.75M9.75 15A1.125 1.125 0 018.625 16.125H6.375M9.75 15A1.125 1.125 0 008.625 13.875v-1.5M9.75 15h3.375" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 3.375V1.5a1.125 1.125 0 00-1.125-1.125h-9.75A1.125 1.125 0 004.5 1.5v1.875m12 0c0 .621-.504 1.125-1.125 1.125h-9.75A1.125 1.125 0 014.5 3.375m12 0v9.375c0 .621-.504 1.125-1.125 1.125h-9.75a1.125 1.125 0 01-1.125-1.125V3.375m1.125 0h9.75M4.5 3.375h.008v.015H4.5V3.375z" />
  </svg>
);

const CheckIcon: React.FC<{className?: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className || "w-5 h-5"}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
    </svg>
);

const PromptOutput: React.FC<PromptOutputProps> = ({ indonesianPrompt, englishPrompt, onIndonesianPromptChange }) => {
  const [copied, setCopied] = useState(false);

  const copyToClipboard = useCallback(() => {
    if (!englishPrompt) return;
    navigator.clipboard.writeText(englishPrompt).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }).catch(err => {
      console.error('Failed to copy English prompt: ', err);
      // Fallback or alert can be added here
    });
  }, [englishPrompt]);

  if (!indonesianPrompt && !englishPrompt) return null;

  return (
    <div className="bg-slate-800 shadow-2xl rounded-lg p-6 sm:p-8 mt-8">
      <div className="flex justify-between items-center mb-4 border-b border-slate-700 pb-3">
        <h3 className="text-xl font-semibold text-sky-400">Hasil Prompt</h3>
        {englishPrompt && (
          <button
            onClick={copyToClipboard}
            className={`inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 transition-colors
              ${copied 
                ? 'bg-green-500 hover:bg-green-600 text-white focus:ring-green-500' 
                : 'bg-sky-500 hover:bg-sky-600 text-slate-900 focus:ring-sky-500'
              }`}
            aria-label={copied ? 'Prompt Bahasa Inggris disalin' : 'Salin Prompt Bahasa Inggris'}
          >
            {copied ? <CheckIcon className="w-5 h-5 mr-2" /> : <CopyIcon className="w-5 h-5 mr-2" />}
            {copied ? 'Disalin!' : 'Salin (English)'}
          </button>
        )}
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <h4 className="text-lg font-medium text-sky-300 mb-2">Prompt Bahasa Indonesia (Dapat Diedit)</h4>
          <textarea
            value={indonesianPrompt}
            onChange={(e) => onIndonesianPromptChange(e.target.value)}
            className="w-full h-96 bg-slate-900 p-4 rounded-md text-sm text-slate-200 whitespace-pre-wrap break-words focus:ring-sky-500 focus:border-sky-500 border border-slate-700"
            aria-label="Prompt Bahasa Indonesia yang dapat diedit"
          />
        </div>
        <div>
          <h4 className="text-lg font-medium text-sky-300 mb-2">Prompt Bahasa Inggris (Final)</h4>
          <div className="w-full h-96 bg-slate-900 p-4 rounded-md overflow-auto border border-slate-700">
            <pre className="text-sm text-slate-200 whitespace-pre-wrap break-words" aria-live="polite">
              {englishPrompt || "Terjemahan Bahasa Inggris akan muncul di sini..."}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PromptOutput;