import React from 'react';
import { VeoMultiCharacterPromptFormState, CharacterData, SelectOption } from '../types';

interface CharacterInputFormProps {
  formData: VeoMultiCharacterPromptFormState;
  onInputChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => void;
  onCharacterInputChange: (characterIndex: number, field: keyof Omit<CharacterData, 'id'>, value: string) => void;
  onGeneratePrompt: () => void;
  onResetForm: () => void;
  isLoading: boolean;
}

const MAX_CHARACTERS = 6;

const cameraMovementOptions: SelectOption[] = [
  { value: "", label: "Pilih Gerakan Kamera..." },
  { value: "Static Shot", label: "Static Shot (Bidikan Statis)" },
  { value: "Pan (Right/Left)", label: "Pan (Geser Kanan/Kiri)" },
  { value: "Tilt (Up/Down)", label: "Tilt (Miring Atas/Bawah)" },
  { value: "Zoom (In/Out)", label: "Zoom (Perbesar/Perkecil)" },
  { value: "Dolly (In/Out)", label: "Dolly (Maju/Mundur Dengan Kamera)" },
  { value: "Truck (Right/Left)", label: "Truck (Geser Lateral Kanan/Kiri Dengan Kamera)" },
  { value: "Pedestal (Up/Down)", label: "Pedestal (Naik/Turun Dengan Kamera)" },
  { value: "Rack Focus", label: "Rack Focus (Fokus Berpindah)" },
  { value: "Crane Shot", label: "Crane Shot (Bidikan Derek)" },
  { value: "Steadicam Shot", label: "Steadicam Shot (Bidikan Steadicam)" },
  { value: "Handheld Shot", label: "Handheld Shot (Bidikan Genggam)" },
  { value: "Drone Shot", label: "Drone Shot (Bidikan Drone)" },
  { value: "Orbit Shot (360 degrees)", label: "Orbit Shot (Bidikan Orbit 360 Derajat)" },
  { value: "Whip Pan", label: "Whip Pan (Pan Cepat)" },
  { value: "3D Rotation", label: "3D Rotation (Rotasi 3D)" },
  { value: "Arc Shot", label: "Arc Shot (Bidikan Melengkung)" },
  { value: "Vertigo Effect (Dolly Zoom)", label: "Vertigo Effect (Efek Vertigo/Dolly Zoom)" },
  { value: "Point of View (POV) Shot", label: "Point of View (POV) Shot (Bidikan Sudut Pandang)" },
  { value: "Dutch Angle/Tilt", label: "Dutch Angle/Tilt (Sudut Miring Kamera)" },
  { value: "Slow Motion", label: "Slow Motion (Gerak Lambat)" },
  { value: "Time-Lapse", label: "Time-Lapse (Selang Waktu)" },
  { value: "Tracking Shot", label: "Tracking Shot (Bidikan Mengikuti Objek)" },
  { value: "Worm's Eye View", label: "Worm's Eye View (Perspektif Cacing)" },
  { value: "Bird's Eye View", label: "Bird's Eye View (Perspektif Burung)" },
];

const lightingOptions: SelectOption[] = [
    { value: "", label: "Pilih Pencahayaan..." },
    { value: "Natural Light", label: "Natural Light (Cahaya Alami)" },
    { value: "Studio Light", label: "Studio Light (Cahaya Studio)" },
    { value: "High Key", label: "High Key (Dominan Terang)" },
    { value: "Low Key", label: "Low Key (Dominan Gelap)" },
    { value: "Rembrandt Lighting", label: "Rembrandt Lighting (Pencahayaan Rembrandt)" },
    { value: "Golden Hour", label: "Golden Hour (Jam Emas)" },
    { value: "Blue Hour", label: "Blue Hour (Jam Biru)" },
    { value: "Backlight", label: "Backlight (Cahaya Belakang)" },
    { value: "Silhouette", label: "Silhouette (Siluet)" },
    { value: "Ambient Lighting", label: "Ambient Lighting (Cahaya Sekitar)" },
    { value: "Artificial Lighting", label: "Artificial Lighting (Cahaya Buatan)" },
    { value: "Moody Lighting", label: "Moody Lighting (Pencahayaan Suasana Mendalam)" },
    { value: "Volumetric Lighting", label: "Volumetric Lighting (Cahaya Volumetrik)" },
    { value: "Cinematic Lighting", label: "Cinematic Lighting (Pencahayaan Sinematik)" },
    { value: "Film Noir Lighting", label: "Film Noir Lighting (Pencahayaan Film Noir)" },
    { value: "Hard Light", label: "Hard Light (Cahaya Keras)" },
    { value: "Soft Light", label: "Soft Light (Cahaya Lembut)" },
];

const videoStyleOptions: SelectOption[] = [
    { value: "", label: "Pilih Gaya Video..." },
    { value: "Cinematic", label: "Cinematic (Sinematik)" },
    { value: "Documentary", label: "Documentary (Dokumenter)" },
    { value: "Vlog", label: "Vlog (Gaya Vlog)" },
    { value: "Anime", label: "Anime (Gaya Anime)" },
    { value: "Cartoon", label: "Cartoon (Gaya Kartun)" },
    { value: "Hyperrealistic", label: "Hyperrealistic (Sangat Realistis)" },
    { value: "Photorealistic", label: "Photorealistic (Fotorealistis)" },
    { value: "Vintage Film", label: "Vintage Film (Film Gaya Retro/Lama)" },
    { value: "Fantasy", label: "Fantasy (Fantasi)" },
    { value: "Sci-Fi", label: "Sci-Fi (Fiksi Ilmiah)" },
    { value: "Horror", label: "Horror (Horor)" },
    { value: "Abstract", label: "Abstract (Abstrak)" },
    { value: "Stop Motion", label: "Stop Motion (Animasi Stop Motion)" },
    { value: "Pixel Art", label: "Pixel Art (Seni Piksel)" },
    { value: "Impressionistic", label: "Impressionistic (Impresionistis)" },
    { value: "Steampunk", label: "Steampunk" },
    { value: "Cyberpunk", label: "Cyberpunk" },
    { value: "Minimalist", label: "Minimalist (Minimalis)" },
    { value: "Surreal", label: "Surreal (Surealis)" },
];

const commonInputClass = "mt-1 block w-full bg-slate-800 border-slate-700 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-sky-500 focus:border-sky-500 sm:text-sm text-slate-100 placeholder-slate-500";
const labelClass = "block text-sm font-medium text-sky-300";

const InputField: React.FC<{id: string, label: string, value: string, placeholder: string, onChange: (e: React.ChangeEvent<HTMLInputElement>) => void}> = 
  ({ id, label, value, placeholder, onChange }) => (
  <div className="mb-4">
    <label htmlFor={id} className={labelClass}>{label}</label>
    <input type="text" id={id} name={id} value={value} onChange={onChange} placeholder={placeholder} className={commonInputClass} />
  </div>
);

const TextareaField: React.FC<{id: string, label: string, value: string, placeholder: string, rows?: number, onChange: (e: React.ChangeEvent<HTMLTextAreaElement>) => void}> = 
  ({ id, label, value, placeholder, rows = 3, onChange }) => (
  <div className="mb-4">
    <label htmlFor={id} className={labelClass}>{label}</label>
    <textarea id={id} name={id} value={value} onChange={onChange} placeholder={placeholder} rows={rows} className={commonInputClass}></textarea>
  </div>
);

const SelectField: React.FC<{id: string, label: string, value: string, options: SelectOption[], onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void}> =
  ({ id, label, value, options, onChange }) => (
  <div className="mb-4">
    <label htmlFor={id} className={labelClass}>{label}</label>
    <select id={id} name={id} value={value} onChange={onChange} className={`${commonInputClass} py-2.5`}>
      {options.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
    </select>
  </div>
);


const CharacterInputForm: React.FC<CharacterInputFormProps> = ({ formData, onInputChange, onCharacterInputChange, onGeneratePrompt, onResetForm, isLoading }) => {
  return (
    <div className="bg-slate-800 shadow-2xl rounded-lg p-6 sm:p-8 mb-8">
      <form onSubmit={(e) => { e.preventDefault(); onGeneratePrompt(); }}>
        <section className="mb-8 p-4 border border-slate-700 rounded-lg">
          <h3 className="text-xl font-semibold text-sky-400 mb-4 border-b border-slate-600 pb-2">Detail Adegan Utama</h3>
          <InputField id="sceneTitle" label="Judul Adegan" value={formData.sceneTitle} onChange={onInputChange} placeholder="Mis: Pertemuan di Kafe Hujan" />
          <TextareaField id="sceneLocationTime" label="Latar Tempat & Waktu" value={formData.sceneLocationTime} onChange={onInputChange} placeholder="Mis: Sebuah kafe remang di malam hari, hujan deras di luar, tahun 2077" />
          <SelectField id="cameraMovement" label="Gerakan Kamera" value={formData.cameraMovement} options={cameraMovementOptions} onChange={onInputChange} />
          <SelectField id="lighting" label="Pencahayaan" value={formData.lighting} options={lightingOptions} onChange={onInputChange} />
          <SelectField id="videoStyle" label="Gaya Video" value={formData.videoStyle} options={videoStyleOptions} onChange={onInputChange} />
          <TextareaField id="overallAtmosphere" label="Suasana Keseluruhan" value={formData.overallAtmosphere} onChange={onInputChange} placeholder="Mis: Misterius, tegang, namun ada sedikit harapan" />
          <InputField id="environmentalSound" label="Suara Lingkungan" value={formData.environmentalSound} onChange={onInputChange} placeholder="Mis: Suara hujan, lalu lintas kota yang jauh, denting cangkir kopi" />
        </section>

        {formData.characters.map((character, index) => (
          <section key={index} className="mb-8 p-4 border border-slate-700 rounded-lg">
            <h3 className="text-xl font-semibold text-sky-400 mb-4 border-b border-slate-600 pb-2">
              Karakter {index + 1}
              <input 
                type="text" 
                value={character.name}
                onChange={(e) => onCharacterInputChange(index, 'name', e.target.value)}
                placeholder={`Nama Karakter ${index + 1}`}
                className="ml-4 p-1 text-sm bg-slate-700 border-slate-600 rounded focus:ring-sky-500 focus:border-sky-500"
                aria-label={`Nama Karakter ${index + 1}`}
              />
            </h3>
            <TextareaField 
              id={`characterDescription_${index}`} 
              label="Deskripsi Visual Karakter" 
              value={character.description} 
              onChange={(e) => onCharacterInputChange(index, 'description', e.target.value)}
              placeholder="Mis: Pria tinggi, rambut pirang acak-acakan, mata biru tajam, mengenakan jaket kulit cokelat" 
              rows={3} 
            />
            <InputField 
              id={`characterVoice_${index}`} 
              label="Detail Suara Karakter" 
              value={character.voice} 
              onChange={(e) => onCharacterInputChange(index, 'voice', e.target.value)}
              placeholder="Mis: Suara berat dan serak, berbicara dengan tenang" 
            />
            <TextareaField 
              id={`characterAction_${index}`} 
              label="Aksi Karakter" 
              value={character.action} 
              onChange={(e) => onCharacterInputChange(index, 'action', e.target.value)}
              placeholder="Mis: Memandang keluar jendela, menyesap kopi, mengetuk jari di meja" 
              rows={2}
            />
            <InputField 
              id={`characterExpression_${index}`} 
              label="Ekspresi Karakter" 
              value={character.expression} 
              onChange={(e) => onCharacterInputChange(index, 'expression', e.target.value)}
              placeholder="Mis: Wajah datar, sedikit senyum misterius, tatapan cemas" 
            />
            <TextareaField 
              id={`characterDialogue_${index}`} 
              label="Dialog Karakter" 
              value={character.dialogue} 
              onChange={(e) => onCharacterInputChange(index, 'dialogue', e.target.value)}
              placeholder="Mis: 'Hujan selalu mengingatkanku padanya...'" 
              rows={2}
            />
          </section>
        ))}
        
        <TextareaField id="additionalDetails" label="Detail Tambahan (Opsional)" value={formData.additionalDetails} onChange={onInputChange} placeholder="Mis: Efek slow motion saat karakter bertemu, fokus pada objek tertentu, dll." rows={3} />

        <div className="mt-8 flex flex-col sm:flex-row sm:justify-end space-y-3 sm:space-y-0 sm:space-x-4">
          <button
            type="button"
            onClick={onResetForm}
            disabled={isLoading}
            className="w-full sm:w-auto inline-flex justify-center items-center px-6 py-3 border border-slate-600 shadow-sm text-base font-medium rounded-md text-sky-300 hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 focus:ring-sky-500 transition-colors disabled:opacity-50"
          >
            Reset Form
          </button>
          <button
            type="submit"
            disabled={isLoading}
            className="w-full sm:w-auto inline-flex justify-center items-center px-6 py-3 border border-transparent shadow-sm text-base font-medium rounded-md text-slate-900 bg-sky-400 hover:bg-sky-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 focus:ring-sky-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? (
              <>
                <div className="loader mr-2"></div>
                Generating...
              </>
            ) : (
              'Generate Veo 3 Prompts'
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

export default CharacterInputForm;