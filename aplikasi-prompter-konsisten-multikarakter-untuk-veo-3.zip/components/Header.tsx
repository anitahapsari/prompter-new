import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="w-full max-w-5xl mb-8 text-center">
      <h1 className="text-4xl font-bold text-sky-400">Aplikasi Prompter Konsisten Multikarakter</h1>
      <p className="text-slate-400 mt-2 text-lg">
        Buat prompt Veo 3 yang terstruktur untuk video dengan banyak karakter yang konsisten secara visual, lengkap dengan deskripsi adegan, dialog, dan detail sinematik.
      </p>
    </header>
  );
};

export default Header;