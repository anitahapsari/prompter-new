
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="w-full max-w-3xl mt-12 text-center text-sm text-slate-500 pb-6">
      <p>&copy; {new Date().getFullYear()} Veo 3 Prompt Generator. For illustrative purposes.</p>
      <p>Created with React, TypeScript, and Tailwind CSS.</p>
    </footer>
  );
};

export default Footer;
