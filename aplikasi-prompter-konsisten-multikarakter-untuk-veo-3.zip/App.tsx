import React, { useState, useCallback, useMemo } from 'react';
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { VeoMultiCharacterPromptFormState, CharacterData } from './types';
import CharacterInputForm from './components/CharacterInputForm';
import PromptOutput from './components/PromptOutput';
import Header from './components/Header';
import Footer from './components/Footer';

const MAX_CHARACTERS = 6;

const createInitialCharacterData = (index: number): CharacterData => ({
  id: `karakter_${index + 1}`,
  name: `Karakter ${index + 1}`, // Default name
  description: "",
  voice: "",
  action: "",
  expression: "",
  dialogue: "",
});

const initialFormData: VeoMultiCharacterPromptFormState = {
  sceneTitle: "",
  characters: Array.from({ length: MAX_CHARACTERS }, (_, i) => createInitialCharacterData(i)),
  sceneLocationTime: "",
  cameraMovement: "",
  lighting: "",
  videoStyle: "",
  overallAtmosphere: "",
  environmentalSound: "",
  additionalDetails: "",
};

// Ensure API_KEY is handled by the environment as per guidelines
const API_KEY = process.env.API_KEY; 

const App: React.FC = () => {
  const [formData, setFormData] = useState<VeoMultiCharacterPromptFormState>(initialFormData);
  const [generatedIndonesianPrompt, setGeneratedIndonesianPrompt] = useState<string>("");
  const [generatedEnglishPrompt, setGeneratedEnglishPrompt] = useState<string>("");
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  
  const ai = useMemo(() => {
    if (!API_KEY) {
      console.error("API_KEY is not set. Please ensure it is available in process.env.API_KEY");
      setError("API Key not configured. Please contact the administrator.");
      return null;
    }
    return new GoogleGenAI({ apiKey: API_KEY });
  }, []);


  const handleInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  }, []);

  const handleCharacterInputChange = useCallback((characterIndex: number, field: keyof Omit<CharacterData, 'id'>, value: string) => {
    setFormData(prev => {
      const newCharacters = prev.characters.map((char, idx) => {
        if (idx === characterIndex) {
          return { ...char, [field]: value };
        }
        return char;
      });
      return { ...prev, characters: newCharacters };
    });
  }, []);

  const generatePrompt = useCallback(async () => {
    if (!ai) {
      setError("AI service is not initialized, likely due to a missing API key.");
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    setError(null);
    setGeneratedIndonesianPrompt("");
    setGeneratedEnglishPrompt("");

    const {
      sceneTitle, characters, sceneLocationTime, cameraMovement,
      lighting, videoStyle, overallAtmosphere, environmentalSound, additionalDetails
    } = formData;

    let idPrompt = `Judul Adegan: ${sceneTitle || 'Tidak Berjudul'}\n\n`;
    const activeCharacters = characters.filter(c => c.description.trim() !== '');
    const characterCcIds: string[] = [];

    if (activeCharacters.length > 0) {
      activeCharacters.forEach((char, index) => {
        const charId = char.id || `karakter_${characters.findIndex(c => c === char) + 1}`;
        characterCcIds.push(`--cc_id ${charId}`);
        idPrompt += `Karakter ${index + 1} (ID: ${charId}):\n`;
        idPrompt += `  Nama: ${char.name || `Karakter ${index + 1}`}\n`;
        idPrompt += `  Deskripsi Visual: ${char.description}\n`;
        if (char.voice) idPrompt += `  Detail Suara: ${char.voice}\n`;
        if (char.action) idPrompt += `  Aksi: ${char.action}\n`;
        if (char.expression) idPrompt += `  Ekspresi: ${char.expression}\n`;
        if (char.dialogue) idPrompt += `  Dialog: [[${char.dialogue}]]\n`; // Mark dialogue
        idPrompt += `\n`;
      });
    } else {
      idPrompt += "Tidak ada karakter spesifik yang dideskripsikan.\n\n";
    }

    idPrompt += `Detail Adegan:\n`;
    if (sceneLocationTime) idPrompt += `  Lokasi & Waktu: ${sceneLocationTime}\n`;
    if (cameraMovement) idPrompt += `  Gerakan Kamera: ${cameraMovement}\n`;
    if (lighting) idPrompt += `  Pencahayaan: ${lighting}\n`;
    if (videoStyle) idPrompt += `  Gaya Video: ${videoStyle}\n`;
    if (overallAtmosphere) idPrompt += `  Suasana Keseluruhan: ${overallAtmosphere}\n`;
    if (environmentalSound) idPrompt += `  Suara Lingkungan: ${environmentalSound}\n`;
    if (additionalDetails) idPrompt += `  Detail Tambahan: ${additionalDetails}\n`;
    
    if (characterCcIds.length > 0) {
      idPrompt += `\nReferensi ID Karakter Konsisten: ${characterCcIds.join(' ')}\n`;
      idPrompt += `Fokus pada interaksi dan kesinambungan visual antar karakter yang dideskripsikan.\n`;
    }
    
    setGeneratedIndonesianPrompt(idPrompt);

    // Translate to English using Gemini
    try {
      const translationPrompt = `Translate the following text accurately from Indonesian to English. IMPORTANT: Any text enclosed in double square brackets, for example [[dialogue text here]], must be preserved exactly as is, including the brackets and the content within them. Do not translate the content inside the double square brackets. Preserve markdown for newlines.\n\nText to translate:\n${idPrompt}`;
      
      const response: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash-preview-04-17',
        contents: translationPrompt,
      });

      let englishText = response.text;
      // Remove the special markers from the final English prompt
      englishText = englishText.replace(/\[\[/g, '').replace(/\]\]/g, '');
      setGeneratedEnglishPrompt(englishText);

    } catch (e: any) {
      console.error("Error during translation: ", e);
      setError(`Failed to translate prompt: ${e.message || 'Unknown error'}`);
      setGeneratedEnglishPrompt("Translation failed.");
    } finally {
      setIsLoading(false);
    }

  }, [formData, ai]);

  const resetForm = useCallback(() => {
    setFormData(initialFormData);
    setGeneratedIndonesianPrompt("");
    setGeneratedEnglishPrompt("");
    setError(null);
  }, []);

  const handleIndonesianPromptChange = useCallback((newPrompt: string) => {
    setGeneratedIndonesianPrompt(newPrompt);
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-slate-900 text-slate-100 items-center px-4 py-6">
      <Header />
      <main className="w-full max-w-5xl flex-grow container mx-auto">
        <CharacterInputForm
          formData={formData}
          onInputChange={handleInputChange}
          onCharacterInputChange={handleCharacterInputChange}
          onGeneratePrompt={generatePrompt}
          onResetForm={resetForm}
          isLoading={isLoading}
        />
        {error && <div className="my-4 p-4 bg-red-700 text-white rounded-md text-center" role="alert">{error}</div>}
        {(generatedIndonesianPrompt || generatedEnglishPrompt) && (
          <PromptOutput 
            indonesianPrompt={generatedIndonesianPrompt}
            englishPrompt={generatedEnglishPrompt}
            onIndonesianPromptChange={handleIndonesianPromptChange}
          />
        )}
      </main>
      <Footer />
    </div>
  );
};

export default App;