export interface CharacterData {
  id: string; // e.g., character_1
  name: string; // User-defined or default "Karakter N"
  description: string;
  voice: string;
  action: string;
  expression: string;
  dialogue: string;
}

export interface VeoMultiCharacterPromptFormState {
  sceneTitle: string;
  characters: CharacterData[]; // Array for up to 6 characters
  sceneLocationTime: string;
  cameraMovement: string;
  lighting: string;
  videoStyle: string;
  overallAtmosphere: string;
  environmentalSound: string;
  additionalDetails: string;
}

export interface SelectOption {
  value: string;
  label: string;
}

// FormField definition might not be directly used in the same way, 
// but keeping it if CharacterInputForm needs to derive structure from it.
// However, the new structure is more complex.
export interface FormField {
  id: keyof VeoMultiCharacterPromptFormState | string; // Allow string for dynamic character field IDs
  label: string;
  placeholder: string;
  type: 'input' | 'textarea' | 'select';
  rows?: number;
  options?: SelectOption[];
  characterIndex?: number; // To identify which character this field belongs to
  fieldKey?: keyof CharacterData; // To identify the specific field within CharacterData
}